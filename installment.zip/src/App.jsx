import React from 'react'
import InsForm from './InstallmentForm/InsForm'

const App = () => {
  return (
    <div>
   <InsForm/>
    </div>
  )
}

export default App
